//base by DGXeon
//recode by Always Ziyoo
//YouTube: @Ziyo232
//Telegram: t.me/ziyooffc

/* ● Always Ziyoo ( Andre ) di remehkan?? Tentu ini bukan Ancaman ! */

const fs = require('fs')
const chalk = require('chalk')

//owmner v card
global.ytname = "YT: HiraaZxX" //ur yt chanel name
global.socialm = "IG : Hiraalf" //ur github or insta name
global.location = "Indonesia" //ur location

//new
global.botname = 'HiraaBOT MD' //ur bot name
global.ownernumber = '6283123448708' //ur owner number
global.ownername = '©Hiraa' //ur owner name
global.websitex = "https://whatsapp.com/channel/0029VaoNzzlJJhzQTJBL5n0F" //"https://whatsapp.com/channel/0029VaoNzzlJJhzQTJBL5n0F"
global.wagc = "https://chat.whatsapp.com/B5r22xL4UyX6fnV3msL9LP" //"https://whatsapp.com/channel/0029VaoNzzlJJhzQTJBL5n0F"
global.themeemoji = '🪀'
global.wm = "HiraaZxD"
global.botscript = 'https://whatsapp.com/channel/0029VaoNzzlJJhzQTJBL5n0F' //'https://whatsapp.com/channel/0029VaoNzzlJJhzQTJBL5n0F' //script link
global.packname = "HiraaBOT MD"
global.author = "HiraaZxD"
global.creator = "6283123448708@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["6283123448708"] // Premium User
global.hituet = 0

//bot sett
global.typemenu = 'v8' // menu type 'v1' => 'v8'
global.typereply = 'v3' // reply type 'v1' => 'v3'
global.autoblocknumber = '' //set autoblock country code
global.antiforeignnumber = '' //set anti foreign number country code
global.welcome = false //welcome/left in groups
global.anticall = false //bot blocks user when called
global.autoswview = true //auto status/story view
global.adminevent = false //show promote/demote message
global.groupevent = false //show update messages in group chat
//msg
global.mess = {
	limit: 'Your limit is up <\>',
	nsfw: 'Nsfw is disabled in this group, Please tell the admin to enable',
    done: 'Done ✓',
    error: 'Error !',
    success: 'Succes •'
}
//thumbnail
global.thumb = fs.readFileSync('./XeonMedia/theme/cheemspic.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})